CREATE VIEW canda_last3_month_week AS
  SELECT sub.id,
    COALESCE(invoices.total_invoice_amount1, (0)::numeric) AS total_invoice_amount1,
    COALESCE(invoices.total_invoice_amount2, (0)::numeric) AS total_invoice_amount2,
    (COALESCE(invoices.total_invoice_amount1, (0)::numeric) - COALESCE(invoices.total_invoice_amount2, (0)::numeric)) AS diff
   FROM (subsidiaries sub
     LEFT JOIN ( SELECT invoices_1.subsidiary_id,
            sum(
                CASE
                    WHEN ((invoices_1.invoice_date >= '2017-10-01'::date) AND (invoices_1.invoice_date <= '2017-10-15'::date) AND (invoices_1.status_id = 12)) THEN (invoices_1.invoice_amount + invoices_1.gst)
                    ELSE NULL::numeric
                END) AS total_invoice_amount1,
            sum(
                CASE
                    WHEN ((invoices_1.invoice_date >= '2016-10-01'::date) AND (invoices_1.invoice_date <= '2016-10-15'::date) AND (invoices_1.status_id = 12)) THEN (invoices_1.invoice_amount + invoices_1.gst)
                    ELSE NULL::numeric
                END) AS total_invoice_amount2
           FROM invoices invoices_1
          WHERE (invoices_1.void_flag = false)
          GROUP BY invoices_1.subsidiary_id) invoices ON ((sub.id = invoices.subsidiary_id)));

