CREATE VIEW canda_aging AS
  SELECT sub.id,
    COALESCE(invoices.aging1, (0)::numeric) AS aging1,
    COALESCE(invoices.aging2, (0)::numeric) AS aging2,
    COALESCE(invoices.aging3, (0)::numeric) AS aging3,
    COALESCE(invoices.aging4, (0)::numeric) AS aging4,
    COALESCE(invoices.aging5, (0)::numeric) AS aging5
   FROM (subsidiaries sub
     LEFT JOIN ( SELECT invoices_1.subsidiary_id,
            sum(
                CASE
                    WHEN ((invoices_1.invoice_date >= '2017-12-15'::date) AND (invoices_1.invoice_date <= '2017-12-31'::date) AND (invoices_1.status_id = 6)) THEN invoices_1.invoice_outstanding
                    ELSE NULL::numeric
                END) AS aging1,
            sum(
                CASE
                    WHEN ((invoices_1.invoice_date >= '2017-12-01'::date) AND (invoices_1.invoice_date <= '2017-12-14'::date) AND (invoices_1.status_id = 6)) THEN invoices_1.invoice_outstanding
                    ELSE NULL::numeric
                END) AS aging2,
            sum(
                CASE
                    WHEN ((invoices_1.invoice_date >= '2017-11-15'::date) AND (invoices_1.invoice_date <= '2017-11-30'::date) AND (invoices_1.status_id = 6)) THEN invoices_1.invoice_outstanding
                    ELSE NULL::numeric
                END) AS aging3,
            sum(
                CASE
                    WHEN ((invoices_1.invoice_date >= '2017-11-01'::date) AND (invoices_1.invoice_date <= '2017-11-14'::date) AND (invoices_1.status_id = 6)) THEN invoices_1.invoice_outstanding
                    ELSE NULL::numeric
                END) AS aging4,
            sum(
                CASE
                    WHEN ((invoices_1.invoice_date >= '2017-10-01'::date) AND (invoices_1.invoice_date <= '2017-10-31'::date) AND (invoices_1.status_id = 6)) THEN invoices_1.invoice_outstanding
                    ELSE NULL::numeric
                END) AS aging5
           FROM invoices invoices_1
          WHERE (invoices_1.void_flag = false)
          GROUP BY invoices_1.subsidiary_id) invoices ON ((sub.id = invoices.subsidiary_id)));

