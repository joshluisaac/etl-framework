CREATE VIEW revenue_previous_month AS
  SELECT sub.id,
    COALESCE(invoices.total_invoice_amount, (0)::numeric) AS total_invoice_amount
   FROM (subsidiaries sub
     LEFT JOIN ( SELECT invoices_1.subsidiary_id,
            sum((invoices_1.invoice_amount + invoices_1.gst)) AS total_invoice_amount
           FROM invoices invoices_1
          WHERE ((invoices_1.invoice_date >= '2017-12-01'::date) AND (invoices_1.invoice_date <= '2017-12-31'::date) AND (invoices_1.status_id = 12) AND (invoices_1.void_flag = false))
          GROUP BY invoices_1.subsidiary_id) invoices ON ((sub.id = invoices.subsidiary_id)));

